<?php
//填写自己的appid
$client_id = '801065573';
//填写自己的appkey
$client_secret = '94a5c459cb55826ceeb6c34bb50a4c80';
//调试模式
$debug = false;